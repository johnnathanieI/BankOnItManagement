Bank On It ATM Application

This program allows existing users to log into their bank account and displays
their balance and lets them withdraw and deposit money into their bank account.

July 2, 2022.

Aaron Ribano & John Nisperos

To run the program, change the command directory by using the 'cd' command in command prompt to the directory
which the jar file is in.

Then use the command 'java -jar <filepath>\<filename>.jar'.